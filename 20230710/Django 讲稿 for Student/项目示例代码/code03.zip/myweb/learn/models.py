from django.db import models

# Create your models here.
'''
课程表映射类，包括课程名字、发布时间和学习人数等属性
'''
class Course(models.Model):
    # 定义类内属性
    # name 属性
    # 对应到数据表中的字段类型为字符串型，并设置字段最大长度。
    name = models.CharField(max_length=64)
    # pub_date 属性
    # 对应到数据表中的字段类型为 Date 日期类型
    pub_date = models.DateField()
    # stu_number 属性
    # 对应到数据表中的字段类型为 Integer 类型，并设置字段的默认值为 0
    stu_number = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    def __repr__(self):
        return f'<Course: {self.name}>'

