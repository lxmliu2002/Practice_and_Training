# 讲授7新增：learn应用的urls.py
from django.urls import path
from .views import index, courses, course
# learn/urls.py
urlpatterns = [
        path('', index),
        path('courses', courses),
        path('course/<int:id>', course)
]
